#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <./inc/tm4c123gh6pm.h>
#include <inc/hw_memmap.h>
#include <inc/hw_types.h>
#include <driverlib/gpio.h>
#include <driverlib/pin_map.h>
#include <driverlib/sysctl.h>
#include <driverlib/uart.h>
#include <driverlib/interrupt.h>


volatile int speed_count = 32;
volatile int led_type = 0;
volatile int cmd_mode = 0;
volatile int command_index=0;

int flag = 0;
int counter = 1;
int valid = 0;

#define red_on        GPIO_PORTF_DATA_R = 0x02;
#define magenta_on    GPIO_PORTF_DATA_R = 0x06;
#define blue_on       GPIO_PORTF_DATA_R = 0x04;
#define cyan_on       GPIO_PORTF_DATA_R = 0x0C;
#define green_on      GPIO_PORTF_DATA_R = 0x08;
#define yellow_on     GPIO_PORTF_DATA_R = 0x0A;
#define white_on      GPIO_PORTF_DATA_R = 0x0E;
#define led_off       GPIO_PORTF_DATA_R = 0x00;
#define offset_delay                       1000


 void printstring(char *str);
 void UART0_Transmitter(unsigned char data);
 void delayMs(int n);
 void UARTIntHandler(void);
 void command_parser(void);
 volatile char rx_val[30] ;
 extern volatile int command_index;
 volatile int command_rxd;
 char parsed_cmnd[6];
 char parsed_data[6];
char modify_cmnd[30];
int main()
{

    // GPIO setup
    SYSCTL_RCGC2_R |= 0x00000020;      // Activate clock for Port F

    GPIO_PORTF_LOCK_R = 0x4C4F434B;    // Unlock GPIO Port F
    GPIO_PORTF_CR_R = 0x1F;            // Allow changes to PF4-0
    GPIO_PORTF_AMSEL_R = 0x00;         // Disable analog on PF
    GPIO_PORTF_PCTL_R = 0x00000000;    // PCTL GPIO on PF4-0
    GPIO_PORTF_DIR_R = 0x0E;           // PF4, PF0 in, PF3-1 out
    GPIO_PORTF_AFSEL_R = 0x00;         // Disable alt funct on PF7-0
    GPIO_PORTF_PUR_R = 0x11;           // Enable pull-up on PF0 and PF4
    GPIO_PORTF_DEN_R = 0x1F;           // Enable digital I/O on PF4-0

    // Interrupt setup
    GPIO_PORTF_IS_R &= ~0x11;           // PF0 and PF4 edge-sensitive
    GPIO_PORTF_IBE_R &= ~0x11;          // PF0 and PF4 not both edges
    GPIO_PORTF_IEV_R &= ~0x11;          // PF0 and PF4 falling edge event
    GPIO_PORTF_ICR_R = 0x11;            // Clear flag4 and flag1
    GPIO_PORTF_IM_R |= 0x11;            // Arm interrupt on PF0 and PF4

    NVIC_PRI7_R = (NVIC_PRI7_R & 0xFF1FFFFF) | 0x00A00000;  // Priority 5
    NVIC_EN0_R = 0x40000000;             // Enable interrupt 30 in NVIC
    __asm("CPSIE I\n");                  //Interrupt enable using asm

    // UART SETUP

    SysCtlPeripheralEnable(SYSCTL_PERIPH_UART0);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);

    GPIOPinConfigure(GPIO_PA0_U0RX);
    GPIOPinConfigure(GPIO_PA1_U0TX);
    GPIOPinTypeUART(GPIO_PORTA_BASE, GPIO_PIN_0 | GPIO_PIN_1);

    UARTConfigSetExpClk(UART0_BASE, SysCtlClockGet(), 115200,(UART_CONFIG_WLEN_8 | UART_CONFIG_STOP_ONE | UART_CONFIG_PAR_NONE));
    printstring("Initialization done\n");
    while(1)
    {
        switch(led_type) {
                    case 0:
                        green_on;
                        break;
                    case 1:
                        blue_on;
                        break;
                    case 2:
                        cyan_on;
                        break;
                    case 3:
                        red_on;
                        break;
                    case 4:
                        yellow_on;
                        break;
                    case 5:
                        magenta_on;
                        break;
                    case 6:
                        white_on;
                        break;
                    case 7:
                        white_on;
                        break;
                    default:
                        break;
                }
                if(cmd_mode==0)
                {
                delayMs(offset_delay / speed_count);
                if(speed_count != 1) led_off;
                delayMs(offset_delay / speed_count);}
                else
                {
                        delayMs(counter);
                        if(speed_count != 1) led_off;
                        delayMs(counter);
                }
     if(command_rxd == 1)
     {
         command_rxd = 0;
         command_parser();
         if(valid == 1)
         {
         if((strcmp(parsed_cmnd, "color")==0))
         {
             switch(parsed_data[0]) {
                                 case 'g':
                                     led_type = 0;
                                     break;
                                 case 'b':
                                     led_type = 1;
                                     break;
                                 case 'c':
                                     led_type = 2;
                                     break;
                                 case 'r':
                                     led_type = 3;
                                     break;
                                 case 'y':
                                     led_type = 4;
                                     break;
                                 case 'm':
                                     led_type = 5;
                                     break;
                                 case 'w':
                                     led_type = 6;
                                     break;
                                 default:
                                     break;
                             }

         }
         else if((strcmp(parsed_cmnd, "blink")==0))
         {
             counter = atoi(parsed_data);
             counter = ((60000)/(2*counter));
             cmd_mode = 1;
         }
         }
        rx_val[0] = '\0';
        command_index = 0;
     }
    }

    return 0;
}


void UART0_Transmitter(unsigned char data)
{
    while((UART0_FR_R & (1<<5)) != 0); /* wait until Tx buffer not full */
    UART0_DR_R = data;                  /* before giving it another byte */
}

void printstring(char *str)
{
  while(*str)
    {
        UART0_Transmitter(*(str++));
    }
}

void command_parser(void)
{
    int a = 0, b = 0;
    for(int i = 0; i<6; i++)
    {
        parsed_data[i] = '\0';
        parsed_cmnd[i] = '\0';
    }
while((rx_val[a] != '\n'))
{
        if(!(((rx_val[a]>47) && (rx_val[a]<58)) || ((rx_val[a]>64) && (rx_val[a]<91)) || ((rx_val[a]>96) && (rx_val[a]<123))))
            {
            a++;
            continue;
            }
        else
        {
            if((rx_val[a]>64) && (rx_val[a]<91))
                rx_val[a] = rx_val[a] + 32;
            modify_cmnd[b] = rx_val[a];
            a++;
            b++;
        }
}
printstring("Entered command is: ");
for(int i = 0; i<b; i++)
        UART0_Transmitter(modify_cmnd[i]);
UART0_Transmitter('\n');
for(int i = 0; i<30; i++)
rx_val[i] = '\0';
for(int i = 0; i<5; i++)
parsed_cmnd[i] = modify_cmnd[i];

printstring("op code is: ");
for(int i = 0; i<5; i++)
    UART0_Transmitter(parsed_cmnd[i]);
UART0_Transmitter('\n');

printstring("operand is: ");
for(int i = 0; i<(b-5); i++)
{
   parsed_data[i] = modify_cmnd[i+5];
   UART0_Transmitter(parsed_data[i]);
}
UART0_Transmitter('\n');
if((strcmp(parsed_cmnd, "color")==0) || (strcmp(parsed_cmnd, "blink")==0))
{
    if((strcmp(parsed_cmnd, "color")==0))
    {
        if(!((strcmp(parsed_data, "red")==0) ||(strcmp(parsed_data, "white")==0) ||(strcmp(parsed_data, "yellow")==0)\
         ||(strcmp(parsed_data, "magenta")==0)||(strcmp(parsed_data, "green")==0)||(strcmp(parsed_data, "blue")==0)\
         ||(strcmp(parsed_data, "cyan")==0)))
        {
           goto  label;
        }
    }
    else
    {
        for(int i = 0; i<(b-5); i++)
        {
           if(!((parsed_data[i] > 47 )&& (parsed_data[i] < 58)))
               goto label;
        }
    }
    printstring("valid command");
    valid = 1;
}
else
{
label: printstring("**********  ENTERED COMMAND IS INVALID  *******\n");
printstring("ENTER THE FOLLOWING COMMANDS ONLY\n");
printstring("1. blink blink_rate        2. color color_type\n");
valid = 0;
return;
}

}


void delayMs(int n) {
    int i, j;
    for(i = 0; i < n; i++)
        for(j = 0; j < 3180; j++) {
            if(UARTCharsAvail(UART0_BASE))
            {
                rx_val[command_index] = UARTCharGet(UART0_BASE);
                if(rx_val[command_index]== '\n')
                    command_rxd = 1;
                (command_index>30)? (command_index = 0): (command_index++);
            }
        }  // Do nothing for 1 ms

}


