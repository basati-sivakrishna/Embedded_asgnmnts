
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#include <./inc/tm4c123gh6pm.h>
#include <inc/hw_memmap.h>
#include <inc/hw_types.h>
#include <driverlib/gpio.h>
#include <driverlib/pin_map.h>
#include <driverlib/sysctl.h>
#include <driverlib/uart.h>
#include <driverlib/interrupt.h>
#include<driverlib/systick.h>
#include<driverlib/timer.h>

#ifndef KEYPAD_H_
#include"C:\Users\basat\Downloads\OneDrive_1_5-2-2024\keypad.h"
#endif
#ifndef GPIO_H_
#include"C:\Users\basat\Downloads\OneDrive_1_5-2-2024\GPIO.h"
#endif


#define red_on        GPIO_PORTF_DATA_R = 0x02;
#define magenta_on    GPIO_PORTF_DATA_R = 0x06;
#define blue_on       GPIO_PORTF_DATA_R = 0x04;
#define cyan_on       GPIO_PORTF_DATA_R = 0x0C;
#define green_on      GPIO_PORTF_DATA_R = 0x08;
#define yellow_on     GPIO_PORTF_DATA_R = 0x0A;
#define white_on      GPIO_PORTF_DATA_R = 0x0E;
#define led_off       GPIO_PORTF_DATA_R = 0x00;
#define offset_delay                       1000


char str[20];
int data = 0;
char ttt[9] = {' ',' ',' ',' ',' ',' ',' ',' ',' '};

volatile int speed_count = 32;
volatile int led_type = 0;
volatile int update = 0;
volatile int cmd_mode = 0;
volatile int command_index=0;
volatile int led_cycle_count = 0;
volatile int msec = 0;
volatile int sec = 0;
volatile char rx_val[30] ;
volatile int changed = 0;
volatile unsigned long long int millis = 0;
extern volatile int command_index;
volatile int coloumn_pressed = 0;
volatile int command_rxd;
volatile int captured_time_sec = 0;
volatile int captured_time_msec = 0;
volatile int captured = 0;
volatile bool down_cnt  = 0;
volatile int d_msec = 0;
volatile int d_sec = 0;
char parsed_cmnd[6];
char parsed_cmnd1[5];
char parsed_cmnd2[7];
char parsed_data[12];
char modify_cmnd[30];
int flag = 0;
int counter = 1;
int valid = 0;
int inputs = 0;
uint8_t pos0_data = 0X3F;
uint8_t pos1_data = 0X3F;
uint8_t pos2_data = 0X3F;
uint8_t pos3_data = 0X3F;
uint8_t command_type = 0;
uint8_t key_pressed = 0;
uint8_t data1 = 0x08;
volatile uint8_t resume_pause = 1;
volatile uint8_t start_stop = 0;
char mem_string[10];
uint32_t mem_add = 0;
bool user = 0;
volatile bool full = 0;
volatile bool empty = 0;
uint8_t *start_version;
uint32_t *end_version;
int new_game = 0;

void delayMs( int n );
void printstring(char *str);
void UART0_Transmitter(unsigned char data);
void SSD_Display(int pos, int data, int digit);
void command_parser(void);
void SSD_Check(void);
void wait( int n );
void ClearLCD();
void DataEnablePulse();
void InstrEnablePulse();
void writeStringLCD(char s[], int line);
void LCD_Initialization();
void delay_lcd( int n);


void SysTick_Handler(void)
{
    millis++;
    if(down_cnt == 0)
    {
    if(start_stop && resume_pause)
    {
    if(msec>8)
    {
        msec=0;
        (sec>998)?(sec=0):(sec++);
    }
    else
        msec++;
    }
    }
    else
    {
//        dsec dmsec
        if(d_msec==0)
        {
            d_msec = 9;
            d_sec--;
            if(d_sec<1)
            {
                down_cnt = 0;
            }
        }
        else
        {
            d_msec--;
        }

    }

SysTickValueGet();
}

void SSD_init(void)
{
    SYSCTL_RCGC2_R |= 0x00000003;       // enable clock to GPIOA, GPIOB at clock gating control register
    // Enable the GPIO pins
    // For PORTB, all pins are used to set 7 segment display
    // For PORTA, pins 7 to 4 are used for selecting one of the four 7 segment display
    GPIO_PORTA_DIR_R |= 0xF0;       // PA4 to PA7 set to output
    GPIO_PORTB_DIR_R |= 0xFF;       // PB0 to PB7 set to output

    // enable the GPIO pins for digital function
    GPIO_PORTA_DEN_R |= 0xF0;       // enabling PA4 to PA7
    GPIO_PORTB_DEN_R |= 0xFF;       // enabling PB0 to PB8

}

void check_win(void)
{
if(inputs>=5)
{
    int win = 0;
        char user;
        int map[8][3] = {{0,1,2}, {0,3,6}, {0,4,8}, {1,4,7}, {2,5,8}, {2,4,6}, {3,4,5}, {6,7,8}};
        int arr[3] = {0,0,0};
//        char ttt[9] = {'X','0','0','0','X','0','X','X','0'};
        for(int i = 0; i<8; i++)
        {
            for(volatile int j = 0; j<3; j++)
            arr[j] = map[i][j];
            if((ttt[arr[0]] == ttt[arr[1]] && ttt[arr[0]] == ttt[arr[2]]) && ttt[arr[0]] !=' ')
            {
                win = 1;
                user = ttt[arr[0]];
            }
            if(win)
            goto win_label;
        }
        win_label: if(win)
        {
            printstring("############## USER ");
//            if(user == '0')
                UART0_Transmitter(user);
//            else
//                UART0_Transmitter(2+'0');
            printstring(" WON   #################\n\r");
            new_game = 1;
            inputs = 0;
        }
        else
        {
            if(inputs == 9)
            {
            printstring("DRAW\n\r");
            new_game = 1;
            }
        }
}
if(new_game)
{
    for(int i = 0; i<9; i++)
    {
        ttt[i] =' ';
    }
    inputs = 0;
    new_game = 0;
}

}

void Timer1_Handler(void)
{
    if(full)
        GPIO_PORTF_DATA_R |= 1<<1;
    else if(empty)
        GPIO_PORTF_DATA_R &= ~(1<<1);
    else
        GPIO_PORTF_DATA_R ^= 1<<1;
    TIMER1_ICR_R  |= 1<<0;
}
long map(long x, long in_min, long in_max, long out_min, long out_max) {
  return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}
int main(void)
{
       SYSCTL_RCGC2_R |= 0x00000020;      // Activate clock for Port F

       GPIO_PORTF_LOCK_R = 0x4C4F434B;    // Unlock GPIO Port F
       GPIO_PORTF_CR_R = 0x1F;            // Allow changes to PF4-0
       GPIO_PORTF_AMSEL_R = 0x00;         // Disable analog on PF
       GPIO_PORTF_PCTL_R = 0x00000000;    // PCTL GPIO on PF4-0
       GPIO_PORTF_DIR_R = 0x0E;           // PF4, PF0 in, PF3-1 out
       GPIO_PORTF_AFSEL_R = 0x00;         // Disable alt funct on PF7-0
       GPIO_PORTF_PUR_R = 0x11;           // Enable pull-up on PF0 and PF4
       GPIO_PORTF_DEN_R = 0x1F;           // Enable digital I/O on PF4-0

       // Interrupt setup for portf
       GPIO_PORTF_IS_R &= ~0x11;           // PF0 and PF4 edge-sensitive
       GPIO_PORTF_IBE_R &= ~0x11;          // PF0 and PF4 not both edges
       GPIO_PORTF_IEV_R &= ~0x11;          // PF0 and PF4 falling edge event
       GPIO_PORTF_ICR_R = 0x11;            // Clear flag4 and flag1
       GPIO_PORTF_IM_R |= 0x11;            // Arm interrupt on PF0 and PF4
       NVIC_PRI7_R = (NVIC_PRI7_R & 0xFF1FFFFF) | 0x00A00000;  // Priority 5
       NVIC_EN0_R |= 0x40000000;             // Enable interrupt 30 in NVIC
       __asm("CPSIE I\n");                  //Interrupt enable using asm
       GPIO_PORTF_DATA_R = 0x00;

//       Systick setup
       SysTickPeriodSet(1600000-1);
       SysTickIntEnable();
       SysTickEnable();

       // UART SETUP
       SysCtlPeripheralEnable(SYSCTL_PERIPH_UART0);
       SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);
       GPIOPinConfigure(GPIO_PA0_U0RX);
       GPIOPinConfigure(GPIO_PA1_U0TX);
       GPIOPinTypeUART(GPIO_PORTA_BASE, GPIO_PIN_0 | GPIO_PIN_1);
       UARTConfigSetExpClk(UART0_BASE, SysCtlClockGet(), 115200,(UART_CONFIG_WLEN_8 | UART_CONFIG_STOP_ONE | UART_CONFIG_PAR_NONE));
       printstring("Initialization done\n\r\r");
       //int i;
              int x = 4999;
              float temp;
              int temp2;
              int result1=0;
              unsigned long long int curr_time =0;
              /* Enable Peripheral Clocks */

              // Enable Peripheral Clocks
              SYSCTL_RCGCPWM_R |= 1;       // Enable clock to PWM0
              SYSCTL_RCGCGPIO_R |= 0x00000010;        // Enable clock at GPIOE (for ADC0)
              SYSCTL_RCC_R |= 0x001E0000;  // Enable divisor for PWM clock (clk/64)
              // Enable port PE5 for PWM0 M0PWM5
              GPIO_PORTE_AFSEL_R = 0x20;   // PE5 uses alternate function
              GPIO_PORTE_PCTL_R &= ~0x00F00000; // Make PE5 PWM output pin
              GPIO_PORTE_PCTL_R |= 0x00400000;  // Function 4 of pin PE5 -> M0PWM5
              GPIO_PORTE_DEN_R |= 0x20;    // Digital enable for PE5
              PWM0_2_CTL_R = 0;            // Stop counter
              PWM0_2_GENB_R = 0x0000008C;  // M0PWM5 output set when reload
                                           // Clear when match PWMCMPA
              PWM0_2_LOAD_R = 5000;        // Set load value for 50Hz : ((16MHz/64) / 50 Hz) = 5000
              PWM0_2_CMPA_R = 4400;        // set duty cycle to 180 degree for servo
              PWM0_2_CTL_R = 1;            // start timer
              PWM0_ENABLE_R = 0x20;        // Start PWM0 ch5
//
              SYSCTL_RCGCGPIO_R |= 0x01;
              GPIO_PORTA_DIR_R |= (1<<3)|(1<<2);
              GPIO_PORTA_DEN_R |= (1<<3)|(1<<2);
              GPIO_PORTA_DR8R_R |= (1<<2);

              GPIO_PORTA_DATA_R |= (1<<3);
              GPIO_PORTA_DATA_R &= ~(1<<2);
              GPIO_PORTA_DATA_R &= ~(1<<3);
              GPIO_PORTA_DATA_R |= (1<<2);

              volatile int result;
              SYSCTL_RCGCADC_R |= 0x00000001; /* enable clock to ADC0 */
              SYSCTL_RCGCGPIO_R |= 0x10; /* enable clock to PE (AIN0 is on PE3) */

              ADC0_ACTSS_R |= 0x00000008; /* enable ADC0 sequencer 3 */
              ADC0_EMUX_R &= ~0xF000; /* software trigger conversion */
              ADC0_SSMUX3_R = 0; /* get input from channel 0 */
              /* initialize PE3 for AIN0 input */
              GPIO_PORTE_AFSEL_R |= 8; /* enable alternate function */
              GPIO_PORTE_DEN_R &= ~8; /* disable digital function */
              GPIO_PORTE_AMSEL_R |= 8; /* enable analog function */
              ADC0_SSCTL3_R |= 6; /* take one sample at a time, set flag at 1st sample */
              ADC0_ACTSS_R |= 8; /* enable ADC0 sequencer 3 */
    SSD_init();
    GPIO_PORTB_DATA_R &= ~(0XFF);
    GPIO_PORTF_DATA_R = 0;
    GPIO_PORTF_DATA_R = 0x01;
    //timer setup
    SYSCTL_RCGCTIMER_R |= 1<<1;
    TIMER1_CTL_R &= (~(1<<0));
    TIMER1_CFG_R = 0X4;
    TIMER1_TAMR_R = 0X2;
    TIMER1_TAPR_R |= 0XFF;
    TIMER1_TAILR_R = 6250;
    TIMER1_ICR_R |= 1<<0;
    TIMER1_CTL_R |= 1<<0;
    TIMER1_IMR_R |= 1<<0;
    NVIC_EN0_R |= 0X200000; // INTERRUPT 21
       while(1)
       {

           ADC0_PSSI_R |= 8; /* start a conversion sequence 3 */
                           while((ADC0_RIS_R & 8) == 0)
                           {
//                               delayMs(1);
                           }
                            /* wait for conversion complete */
                           result = ADC0_SSFIFO3_R; /* read conversion result */
                           ADC0_ISC_R = 8; /* clear completion flag */
                           temp=(((result)/4095.0)*4999.0);
                           temp2=(int)temp;
                           x=4999-temp2;
                           PWM0_2_CMPA_R=x;

           if((result-result1)>50 || (result-result1)<(-50))
               {
               curr_time = millis;
               TIMER1_TAILR_R =  map(result, 10,4050,62500,3125);
               }
           if(result>4050)
               full = 1;
           else if(result<50)
               empty = 1;
           else
           {
               full = 0;
               empty = 0;
           }
           if(millis-curr_time < 50)
           {
               SSD_Display(0, result%10 , 0);
               SSD_Display(0, result/10, 1);
           }
           else if(down_cnt ==0 )
           {
               SSD_Display(0, msec, 0);
               SSD_Display(0, sec, 1);
           }
           else
           {
               SSD_Display(0, d_msec, 0);
               SSD_Display(0, d_sec, 1);
           }
           result1 = result;
           if(command_rxd)
           {
               command_parser();
               command_rxd = 0;
           }delayMs(50);

       }
return 0;
}


void SSD_Display(int pos, int data, int digit)
{
    if(digit == 0)
    {
    switch(data)
    {
    case 0:
        if(pos == 0)
        pos0_data = 0X3F;
        else if(pos == 1)
        pos1_data = 0X3F;
        else if(pos == 2)
        pos2_data = 0X3F;
        else if(pos == 3)
        pos3_data = 0X3F;
//        GPIO_PORTB_DATA_R = 0X3F;
        break;
    case 1:
        if(pos == 0)
        pos0_data = 0X06;
        else if(pos == 1)
        pos1_data = 0X06;
        else if(pos == 2)
        pos2_data =0X06;
        else if(pos == 3)
        pos3_data = 0X06;

//        GPIO_PORTB_DATA_R = 0X06;
        break;
    case 2:
        if(pos == 0)
        pos0_data = 0X5B;
        else if(pos == 1)
        pos1_data = 0X5B;
        else if(pos == 2)
        pos2_data =0X5B;
        else if(pos == 3)
        pos3_data = 0X5B;
//        GPIO_PORTB_DATA_R = 0X5B;
        break;
    case 3:
        if(pos == 0)
        pos0_data =  0X4F;
        else if(pos == 1)
        pos1_data =  0X4F;
        else if(pos == 2)
        pos2_data = 0X4F;
        else if(pos == 3)
        pos3_data =  0X4F;
//        GPIO_PORTB_DATA_R = 0X4F;
        break;
    case 4:
        if(pos == 0)
        pos0_data =  0X66;
        else if(pos == 1)
        pos1_data =  0X66;
        else if(pos == 2)
        pos2_data =  0X66;
        else if(pos == 3)
        pos3_data =  0X66;
//        GPIO_PORTB_DATA_R = 0X66;
        break;
    case 5:
        if(pos == 0)
        pos0_data = 0X6D;
        else if(pos == 1)
        pos1_data = 0X6D;
        else if(pos == 2)
        pos2_data =0X6D;
        else if(pos == 3)
        pos3_data = 0X6D;
//        GPIO_PORTB_DATA_R = 0X6D;
        break;
    case 6:
        if(pos == 0)
        pos0_data =  0X7D;
        else if(pos == 1)
        pos1_data =  0X7D;
        else if(pos == 2)
        pos2_data =  0X7D;
        else if(pos == 3)
        pos3_data =  0X7D;
//        GPIO_PORTB_DATA_R = 0X7D;
        break;
    case 7:
        if(pos == 0)
        pos0_data =  0X07;
        else if(pos == 1)
        pos1_data =  0X07;
        else if(pos == 2)
        pos2_data =  0X07;
        else if(pos == 3)
        pos3_data =  0X07;
//        GPIO_PORTB_DATA_R = 0X07;
        break;
    case 8:
        if(pos == 0)
        pos0_data = 0X7F;
        else if(pos == 1)
        pos1_data = 0X7F;
        else if(pos == 2)
        pos2_data = 0X7F;
        else if(pos == 3)
        pos3_data = 0X7F;
//        GPIO_PORTB_DATA_R = 0X7F;
        break;
    case 9:
        if(pos == 0)
        pos0_data = 0X6F;
        else if(pos == 1)
        pos1_data = 0X6F;
        else if(pos == 2)
        pos2_data = 0X6F;
        else if(pos == 3)
        pos3_data = 0X6F;
//        GPIO_PORTB_DATA_R = 0X6F;
        break;
    default:
        GPIO_PORTB_DATA_R = 0X00;

    }
    return;
    }
    else
    {
        int x = 0, y = 0, z = 0;
        x = data % 10;
        y = ((data/10)%10);
        z = data / 100;
        SSD_Display(1, x, 0);
        SSD_Display(2, y, 0);
        SSD_Display(3, z, 0);
    }

}


void UART0_Transmitter(unsigned char data)
{
    while((UART0_FR_R & (1<<5)) != 0); /* wait until Tx buffer not full */
    UART0_DR_R = data;                  /* before giving it another byte */
}

void printstring(char *str)
{
  while(*str)
    {
        UART0_Transmitter(*(str++));
    }
}

void command_parser(void)
{
    int a = 0, b = 0;
//    poke_index=0;
//    char poke_data[12];

    for(int i = 0; i<7; i++)
    {
        parsed_data[i] = '\0';
        parsed_cmnd[i] = '\0';
        parsed_cmnd1[i] = '\0';
        parsed_cmnd2[i] = '\0';

    }
while((rx_val[a] != '\r'))
{
        if(!(((rx_val[a]>47) && (rx_val[a]<58)) || ((rx_val[a]>64) && (rx_val[a]<91)) || ((rx_val[a]>96) && (rx_val[a]<123))))
            {
            a++;
            continue;
            }
        else
        {
            if((rx_val[a]>64) && (rx_val[a]<91))
                rx_val[a] = rx_val[a] + 32;
            modify_cmnd[b] = rx_val[a];
            a++;
            b++;
        }
        modify_cmnd[b] = '\0';
}
printstring("Entered command is: ");
for(int i = 0; i<b; i++)
        UART0_Transmitter(modify_cmnd[i]);
UART0_Transmitter('\n');
UART0_Transmitter('\r');

for(int i = 0; i<6; i++)
{
 if(i<4)
     parsed_cmnd1[i] = modify_cmnd[i];

    if(i<5)
parsed_cmnd[i] = modify_cmnd[i];
    parsed_cmnd2[i]  = modify_cmnd[i];
}

if((strcmp(parsed_cmnd,"color")==0))
    command_type = 1;
else if(((strcmp(parsed_cmnd,"blink")==0)))
    command_type = 2;

else if(((strcmp(parsed_cmnd,"pause")==0)))
    command_type = 3;
else if(((strcmp(parsed_cmnd,"start")==0)))
    command_type = 4;
else if(((strcmp(parsed_cmnd2,"resume")==0)))
    command_type = 5;
else if(((strcmp(parsed_cmnd1,"stop")==0)))
    command_type = 6;

else if(((strcmp(parsed_cmnd1,"tset")==0)))
    command_type = 7;
else if(((strcmp(parsed_cmnd1,"poke")==0)))
    command_type = 8;
else
    command_type = 9;

switch(command_type)
{
case 1:
    for(int i = 0; i<(b-5); i++)
       parsed_data[i] = modify_cmnd[i+5];
    if(!((strcmp(parsed_data, "red")==0) ||(strcmp(parsed_data, "white")==0) ||(strcmp(parsed_data, "yellow")==0)\
             ||(strcmp(parsed_data, "magenta")==0)||(strcmp(parsed_data, "green")==0)||(strcmp(parsed_data, "blue")==0)\
             ||(strcmp(parsed_data, "cyan")==0)))
            {
               goto  label;
            }
    valid = 1;
    break;

case 2:
           for(int i = 0; i<(b-5); i++)
            {
               parsed_data[i] = modify_cmnd[i+5];
               if(!((parsed_data[i] > 47 )&& (parsed_data[i] < 58)))
                   goto label;
            }
           valid = 1;
    break;

case 3:  // pause
    GPIO_PORTF_DATA_R = 0X00;
        data1 = 0x04;
        resume_pause = 0;
        captured = 1;
        update = 2;
        valid  = 1;
    break;

case 4:  //start
    start_stop = 1;
    update = 1;
    GPIO_PORTF_DATA_R = 0X00;
        data1 = 0x08;
        captured = 1;
    valid = 1;
    break;

case 5:  //resume
    resume_pause = 1;
    update = 1;
    captured = 1;
    valid  = 1;
    break;
case 6:  //stop
    start_stop = 0;
    update = 0;
    valid = 1;
    captured = 1;
    msec = 0;
    sec= 0;
    break;
case 7:
    //peek
    /*
    for(int i = 0; i<8; i++)   //storing address in array and checking the values given
     {
        parsed_data[i] = modify_cmnd[i+6];
        if(!(((parsed_data[i] > 47 )&& (parsed_data[i] < 58))||((parsed_data[i] >='a')&&(parsed_data[i] <='f'))))
            goto label;
     }
    ascii_to_hex(parsed_data);
    if(!(mem_add >= start_version && mem_add <(start_version+12)))
    {
    printstring(" ******Invalid address*******");
    UART0_Transmitter('\n');
    UART0_Transmitter('\r');
    printstring(" address range: ");
    hex_to_ascii(start_version);
    printstring(mem_string);
    printstring(" TO ");
    hex_to_ascii(start_version+12);
    printstring(mem_string);
    UART0_Transmitter('\n');
    UART0_Transmitter('\r');
}

    else{
    printstring(" DATA IN MEMORY LOC(");
    hex_to_ascii(mem_add);
    printstring(mem_string);
    printstring("): ");
    char *mem_ptr = (char*)(mem_add);
    UART0_Transmitter((*(mem_ptr)));
    UART0_Transmitter('\n');
    UART0_Transmitter('\r');
    valid = 1;
    goto wait_label;
    }
    */
    //tset
    for(int i = 0; i<(b-4); i++)
               {
                  parsed_data[i] = modify_cmnd[i+4];
                  if(!((parsed_data[i] > 47 )&& (parsed_data[i] < 58)))
                      goto label;
               }
    if(atoi(parsed_data)>999)
        goto label;
    d_msec = 0;
    down_cnt = 1;
    d_sec = atoi(parsed_data);
    valid = 1;
    break;
case 8:   //poke
    /*
    poke_index=0;
    for(int i = 0; i<8; i++)   //storing address in array and checking the values given
         {
            parsed_data[i] = modify_cmnd[i+6];
            if(!(((parsed_data[i] > 47 )&& (parsed_data[i] < 58))||((parsed_data[i] >='a')&&(parsed_data[i] <='f'))))
                goto label;
         }
        ascii_to_hex(parsed_data);

//        for(int i=8;modify_cmnd[i+6]!='\0';i++)
//        {
//            poke_data[i-8] = modify_cmnd[i+6];
//            poke_index++;
//        }
       volatile int x = 0;
        while(rx_val[x] != '"')
        {
        x++;
        }
        x++;
        for(int i = 0; rx_val[x] != '"'; i++)
        {
            poke_data[i] = rx_val[x];
            x++;
            poke_index++;
        }
        if((mem_add+poke_index)>(start_version+12))
        {
            printstring("*******DATA OVERFLOW**********");
            UART0_Transmitter('\n');
            UART0_Transmitter('\r');

            goto label;
        }
        else
        {
            char *mem_ptr = (char*)(mem_add);
            for(int i=0; i<poke_index; i++)
            {
                (*mem_ptr) = poke_data[i];
                mem_ptr++;
            }
            mem_ptr = (char*)(mem_add);
            for(int i = 0; i<poke_index; i++)
            {
            version_str[((uint8_t*)(mem_add)-start_version)+i] = (*mem_ptr);
            mem_ptr++;
            }
            //update the display
            ClearLCD();
            writeStringLCD(version_str, 1);
            valid = 1;
        }
*/
    break;
case 9:
    goto label;
    break;

default:
    goto label;
    break;
}
for(int i = 0; i<30; i++)
rx_val[i] = '\0';

if(valid == 0){
label: printstring("**********  ENTERED COMMAND IS INVALID  *******\n\r");
printstring("ENTER THE FOLLOWING COMMANDS ONLY\n\r");
printstring("1. blink blink_rate        2. color color_type\n\r");
printstring("3. pause                   4. resume\n\r");
printstring("5. stop                    6. start\n\r");
printstring("7. peek mem_loc            8. poke mem_loc \"data\" \n\r");

valid = 0;
return;
}
//////////////print status/////////////////
printstring("||-------------STATUS OF THE MACHINE--------------||\n\r");
printstring("COMMAND GIVEN ----> ");
for(int i = 0; i<b; i++)
        UART0_Transmitter(modify_cmnd[i]);
UART0_Transmitter('\n');
UART0_Transmitter('\r');
printstring("LED CODE ---->  ");
UART0_Transmitter((led_type+'0'));
UART0_Transmitter('\n');
UART0_Transmitter('\r');
printstring("STATE ---->  ");
if(resume_pause)
    printstring(" RESUME ");
else
    printstring(" PAUSE ");
UART0_Transmitter('\n');
UART0_Transmitter('\r');
/*
printstring(" DATA IN MEMORY LOCS: ");
hex_to_ascii(start_version);
printstring(mem_string);
printstring(" TO ");
hex_to_ascii(start_version+12);
printstring(mem_string);
UART0_Transmitter('\n');
UART0_Transmitter('\r');
for(int i=0; i<12; i++)
{
    hex_to_ascii(start_version);
    printstring(mem_string);
    printstring(": ");
    UART0_Transmitter((*(start_version++)));
    UART0_Transmitter('\n');
    UART0_Transmitter('\r');
}

start_version = &__version_start__;

wait_label: wait(10);
*/
}


void delayMs(int n) {
   volatile int i, j,k;
    for(i = 0; i < n; i++)
        for(j = 0; j < 15; j++) {
            // read serial data

            if(UARTCharsAvail(UART0_BASE))
            {
                rx_val[command_index] = UARTCharGet(UART0_BASE);
                if(rx_val[command_index] == '\b')
                {
                    rx_val[command_index] = '\0';
                    command_index = command_index-1;
                    rx_val[command_index] = '\0';
                    UART0_Transmitter('\b');
                    UART0_Transmitter(' ');
                    UART0_Transmitter('\b');
                    command_index = command_index-1;
                }
                else
                {
                UART0_Transmitter(rx_val[command_index]);
                }
                if(rx_val[command_index]== '\r')
                    command_rxd = 1;
                (command_index>30)? (command_index = 0): (command_index++);
            }
            //refresh display


                GPIO_PORTA_DATA_R &= ~(0xF0);
                GPIO_PORTB_DATA_R = 0;
                GPIO_PORTA_DATA_R = (1<<(4));
                GPIO_PORTB_DATA_R = pos0_data;
                for(k = 0; k < 30; k++) {
                }

                GPIO_PORTA_DATA_R &= ~(0xF0);
                GPIO_PORTB_DATA_R = 0;
                GPIO_PORTA_DATA_R = (1<<(5));
                GPIO_PORTB_DATA_R = pos1_data;//GPIO_PORTB_DATA_R = pos1_data | 0x80; to print dot in ssd
                for(k = 0; k < 30; k++) {
                }
                if(pos2_data != 0x3F || pos3_data != 0x3F)
                {
                GPIO_PORTA_DATA_R &= ~(0xF0);
                GPIO_PORTB_DATA_R = 0;
                GPIO_PORTA_DATA_R = (1<<(6));
                GPIO_PORTB_DATA_R = pos2_data;
                for(k = 0; k < 30; k++) {
                }
                }
if(pos3_data != 0X3F)
{
                GPIO_PORTA_DATA_R &= ~(0xF0);
                GPIO_PORTB_DATA_R = 0;
                GPIO_PORTA_DATA_R = (1<<(7));
                GPIO_PORTB_DATA_R = pos3_data;
                for(k = 0; k < 30; k++) {
                }
}
        }  // Do nothing for 1 ms

}

void wait( int n )
{
    int i, j ;

    for(i = 0; i < n ; i ++)
    {
        for(j = 0; j < 3180; j++);
    }
}



void delay_lcd( int n)
{
    int i, j ;

    for(i = 0; i < n ; i ++)
    {
        for(j = 0; j < 3180; j++);
    }
}



void LCD_Initialization(){
  delay_lcd(200);
  GPIO_PORTB_DATA_R = 0x30;
  GPIO_PORTA_DATA_R = 0x80;
  delay_lcd(1);
  GPIO_PORTA_DATA_R = 0x00;
  delay_lcd(10);
  GPIO_PORTB_DATA_R = 0x30;
  GPIO_PORTA_DATA_R = 0x80;
  delay_lcd(1);
  GPIO_PORTA_DATA_R = 0x00;



  delay_lcd(1);
  GPIO_PORTB_DATA_R = 0x30;
  GPIO_PORTA_DATA_R = 0x80;
  delay_lcd(1);
  GPIO_PORTA_DATA_R = 0x00;
  delay_lcd(1);



  GPIO_PORTB_DATA_R = 0x38;
  GPIO_PORTA_DATA_R = 0x80;
  delay_lcd(1);
  GPIO_PORTA_DATA_R = 0x00;
  delay_lcd(1);



  GPIO_PORTB_DATA_R = 0x01;
  GPIO_PORTA_DATA_R = 0x80;
  delay_lcd(1);
  GPIO_PORTA_DATA_R = 0x00;
delay_lcd(5);



GPIO_PORTB_DATA_R = 0x06;
GPIO_PORTA_DATA_R = 0x80;
delay_lcd(1);
GPIO_PORTA_DATA_R = 0x00;
delay_lcd(1);
GPIO_PORTB_DATA_R = 0x0C;
GPIO_PORTA_DATA_R = 0x80;
delay_lcd(1);
GPIO_PORTA_DATA_R = 0x00;

}


void writeStringLCD(char s[], int line)
{

if (line == 1)
{
GPIO_PORTB_DATA_R = 0x80;
GPIO_PORTA_DATA_R = 0x80;
delay_lcd(3);
GPIO_PORTA_DATA_R = 0x00;
delay_lcd(3);
}
else
{
GPIO_PORTB_DATA_R = 0xC0;
GPIO_PORTA_DATA_R = 0x80;
delay_lcd(3);
GPIO_PORTA_DATA_R = 0x00;
delay_lcd(3);
}

int i = 0;
while (s[i] != '\0')
{
GPIO_PORTB_DATA_R = s[i];
GPIO_PORTA_DATA_R = 0xC0;
delay_lcd(3);
GPIO_PORTA_DATA_R = 0x40;
delay_lcd(3);
i++;
}
}



void InstrEnablePulse(){
GPIO_PORTA_DATA_R = 0x80;
delay_lcd(5);
GPIO_PORTA_DATA_R = 0x00;
delay_lcd(5);
}



void DataEnablePulse(){
GPIO_PORTA_DATA_R = 0xC0;
delay_lcd(3);
GPIO_PORTA_DATA_R = 0x40;
delay_lcd(3);
}


void ClearLCD(){
GPIO_PORTB_DATA_R = 0x01;
InstrEnablePulse();
}




