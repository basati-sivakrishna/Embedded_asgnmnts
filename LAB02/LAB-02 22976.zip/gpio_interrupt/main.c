/*
 * PF4 GPIO SW1
 * PF0 GPIO SW2
 * PF1 GPIO RGB LED (Red)
 * PF2 GPIO RGB LED (Blue)
 * PF3 GPIO RGB LED (Green)
 */

#include <stdint.h>
#include "inc/tm4c123gh6pm.h"

volatile int speed_count = 32;
volatile int led_type = 0;
int flag = 0;

#define red_on        GPIO_PORTF_DATA_R = 0x02;
#define magenta_on    GPIO_PORTF_DATA_R = 0x06;
#define blue_on       GPIO_PORTF_DATA_R = 0x04;
#define cyan_on       GPIO_PORTF_DATA_R = 0x0C;
#define green_on      GPIO_PORTF_DATA_R = 0x08;
#define yellow_on     GPIO_PORTF_DATA_R = 0x0A;
#define white_on      GPIO_PORTF_DATA_R = 0x0E;
#define led_off       GPIO_PORTF_DATA_R = 0x00;
#define offset_delay                       1000

void delayMs(int n);

int main(void) {
    // GPIO setup
    SYSCTL_RCGC2_R |= 0x00000020;      // Activate clock for Port F

    GPIO_PORTF_LOCK_R = 0x4C4F434B;    // Unlock GPIO Port F
    GPIO_PORTF_CR_R = 0x1F;            // Allow changes to PF4-0
    GPIO_PORTF_AMSEL_R = 0x00;         // Disable analog on PF
    GPIO_PORTF_PCTL_R = 0x00000000;    // PCTL GPIO on PF4-0
    GPIO_PORTF_DIR_R = 0x0E;           // PF4, PF0 in, PF3-1 out
    GPIO_PORTF_AFSEL_R = 0x00;         // Disable alt funct on PF7-0
    GPIO_PORTF_PUR_R = 0x11;           // Enable pull-up on PF0 and PF4
    GPIO_PORTF_DEN_R = 0x1F;           // Enable digital I/O on PF4-0

    // Interrupt setup
    GPIO_PORTF_IS_R &= ~0x11;           // PF0 and PF4 edge-sensitive
    GPIO_PORTF_IBE_R &= ~0x11;          // PF0 and PF4 not both edges
    GPIO_PORTF_IEV_R &= ~0x11;          // PF0 and PF4 falling edge event
    GPIO_PORTF_ICR_R = 0x11;            // Clear flag4 and flag1
    GPIO_PORTF_IM_R |= 0x11;            // Arm interrupt on PF0 and PF4

    NVIC_PRI7_R = (NVIC_PRI7_R & 0xFF1FFFFF) | 0x00A00000;  // Priority 5
    NVIC_EN0_R = 0x40000000;             // Enable interrupt 30 in NVIC
    __asm("CPSIE I\n");                  //Interrupt enable using asm

    while(1) {
        switch(led_type) {
            case 0:
                green_on;
                break;
            case 1:
                blue_on;
                break;
            case 2:
                cyan_on;
                break;
            case 3:
                red_on;
                break;
            case 4:
                yellow_on;
                break;
            case 5:
                magenta_on;
                break;
            case 6:
                white_on;
                break;
            case 7:
                white_on;
                break;
            default:
                break;
        }

        delayMs(offset_delay / speed_count);
        if(speed_count != 1) led_off;
        delayMs(offset_delay / speed_count);

    }
}

void delayMs(int n) {
    int i, j;
    for(i = 0; i < n; i++)
        for(j = 0; j < 3180; j++) {}  // Do nothing for 1 ms
}

