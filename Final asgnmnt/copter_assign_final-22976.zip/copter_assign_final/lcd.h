/*
 * lcd.h
 *
 *  Created on: 10-Apr-2024
 *      Author: basat
 */
#include <stdint.h>
#include <stdbool.h>
#include <./inc/tm4c123gh6pm.h>

#ifndef LCD_H_
#define LCD_H_

void delay_lcd( int n)
{
    volatile int i, j;

    for(i = 0; i < n ; i ++)
    {
        for(j = 0; j < 300; j++);
    }
}



void LCD_Initialization(){
  delay_lcd(200);
  GPIO_PORTB_DATA_R = 0x30;
  GPIO_PORTA_DATA_R = 0x80;
  delay_lcd(1);
  GPIO_PORTA_DATA_R = 0x00;
  delay_lcd(10);
  GPIO_PORTB_DATA_R = 0x30;
  GPIO_PORTA_DATA_R = 0x80;
  delay_lcd(1);
  GPIO_PORTA_DATA_R = 0x00;



  delay_lcd(1);
  GPIO_PORTB_DATA_R = 0x30;
  GPIO_PORTA_DATA_R = 0x80;
  delay_lcd(1);
  GPIO_PORTA_DATA_R = 0x00;
  delay_lcd(1);



  GPIO_PORTB_DATA_R = 0x38;
  GPIO_PORTA_DATA_R = 0x80;
  delay_lcd(1);
  GPIO_PORTA_DATA_R = 0x00;
  delay_lcd(1);



  GPIO_PORTB_DATA_R = 0x01;
  GPIO_PORTA_DATA_R = 0x80;
  delay_lcd(1);
  GPIO_PORTA_DATA_R = 0x00;
delay_lcd(5);



GPIO_PORTB_DATA_R = 0x06;
GPIO_PORTA_DATA_R = 0x80;
delay_lcd(1);
GPIO_PORTA_DATA_R = 0x00;
delay_lcd(1);
GPIO_PORTB_DATA_R = 0x0C;
GPIO_PORTA_DATA_R = 0x80;
delay_lcd(1);
GPIO_PORTA_DATA_R = 0x00;

}


void writeStringLCD(char s[], int line)
{
    int i = 0;

if (line == 1)
{
GPIO_PORTB_DATA_R = 0x80;
GPIO_PORTA_DATA_R = 0x80;
delay_lcd(3);
GPIO_PORTA_DATA_R = 0x00;
delay_lcd(3);
}
else
{
GPIO_PORTB_DATA_R = 0xC0;
GPIO_PORTA_DATA_R = 0x80;
delay_lcd(3);
GPIO_PORTA_DATA_R = 0x00;
delay_lcd(3);
}

while (s[i] != '\0')
{
GPIO_PORTB_DATA_R = s[i];
GPIO_PORTA_DATA_R = 0xC0;
delay_lcd(3);
GPIO_PORTA_DATA_R = 0x40;
delay_lcd(3);
i++;
}
}



void InstrEnablePulse(){
GPIO_PORTA_DATA_R = 0x80;
delay_lcd(5);
GPIO_PORTA_DATA_R = 0x00;
delay_lcd(5);
}



void DataEnablePulse(){
GPIO_PORTA_DATA_R = 0xC0;
delay_lcd(3);
GPIO_PORTA_DATA_R = 0x40;
delay_lcd(3);
}


void ClearLCD(){
GPIO_PORTB_DATA_R = 0x01;
InstrEnablePulse();
}




#endif /* LCD_H_ */
