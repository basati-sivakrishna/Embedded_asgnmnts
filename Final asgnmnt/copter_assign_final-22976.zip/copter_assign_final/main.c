/*
   ***********HARDWARE CONNECTIONS***********
timer0_a_load_value -> Main motor PWM
timer1_a_load_value -> Tail motor PWM
timer2_a_load_value -> Servo motor PWM
 * MPU->SCL       - PE4
 * MPU->SDA       - PE5
 * MPU->INT       - PA2
 * USS->ECHO      - PD3
 * USS->TRIG      - PD2
 * MOTOR_1        - PA3
 * MOTOR_2        - PA4
 * SERVO          - PA5
 * POT            - PE3
 * LED -> RED     - PF1
 * LED -> BLUE    - PF2
 * LED -> GREEN   - PF3
 * LCD CONNECTIONS ARE ACCORDING TO EDU-ARM BOARD
 */

#include <stdio.h>

#include <stdint.h>
#include <stdbool.h>
#include "inc/hw_memmap.h"
#include "inc/hw_ints.h"
#include "driverlib/debug.h"
#include "driverlib/gpio.h"
#include "driverlib/interrupt.h"
#include "driverlib/pin_map.h"
#include "driverlib/rom.h"
#include "driverlib/sysctl.h"
#include "driverlib/uart.h"
#include "utils/uartstdio.h"
#include "sensorlib/hw_mpu9150.h"
#include "sensorlib/hw_ak8975.h"
#include "sensorlib/i2cm_drv.h"
#include "sensorlib/ak8975.h"
#include "sensorlib/mpu9150.h"
#include "sensorlib/comp_dcm.h"
#include "drivers/rgb.h"
#include "lcd.h"

volatile int set_base_speed = 0;

#define MPU9150_I2C_ADDRESS     0x68 // Define MPU9150 I2C Address.

#define timer0_a_off            TIMER0_CTL_R &= (~(1<<0))
#define timer0_a_on             TIMER0_CTL_R |= 1<<0
#define timer1_a_on         TIMER1_CTL_R |= 1<<0
#define timer1_a_off           TIMER1_CTL_R &= (~(1<<0))
#define timer2_a_off            TIMER2_CTL_R &= (~(1<<0))
#define timer2_a_on             TIMER2_CTL_R |= 1<<0
#define blue_on        0x04;
#define yellow_on      0x0A;



tCompDCM g_sCompDCMInst;

tI2CMInstance g_sI2CInst;  // Global instance structure for the I2C master driver.

tMPU9150 g_sMPU9150Inst; // Global instance structure for the ISL29023 sensor driver.

tCompDCM g_sCompDCMInst;  // Global Instance structure to manage the DCM state.

volatile uint_fast8_t g_vui8I2CDoneFlag;  // Global flags to alert main that MPU9150 I2C transaction is complete

volatile uint_fast8_t g_vui8ErrorFlag; // Global flags to alert main that MPU9150 I2C transaction error has occurred.

volatile uint_fast8_t g_vui8DataFlag;  // Global flags to alert main that MPU9150 data is ready to be retrieved.

#define PRINT_SKIP_COUNT        10 // Global counter to control and slow down the rate of data to the terminal.


uint32_t g_ui32PrintSkipCounter;
volatile unsigned int time_value1 = 0;
volatile unsigned int time_value2 = 1;
unsigned int distance;
volatile unsigned int trigger_delay = 0; //trigger will be sent for every 200mSec
volatile uint8_t update = 0;

volatile uint8_t avg_data_available = 0;
volatile int result = 0;
volatile uint16_t timer0_a_load_value = 1560;
volatile uint16_t timer1_a_load_value = 1560;
volatile uint16_t timer2_a_load_value = 1560;
volatile uint16_t log_msg = 0;

float global_accel_x = 0;
float global_accel_y = 0;
double global_accel_z = 0;
double last_global_accel_z = 0;

float global_gyro_p = 0;
float global_gyro_y = 0;
float global_gyro_r = 0;

int avg_data1[15];
volatile bool asc_des = 0;
int_fast32_t i32IPart_accel[3], i32FPart_accel[3];
int_fast32_t i32IPart_gyro[3], i32FPart_gyro[3];

float accel_data[3];
float gyro_data[3];


int present_pitch = 0;
int last_pitch = 0;
int present_yaw = 0;
int last_yaw = 0;
float last_z_val = 0.0;
float present_z_val = 0.0;
float present_x_val = 0.0;
float present_y_val = 0.0;

char lcd_msg_1[16] = {"A/D:- F/B:-" };
char lcd_msg_2[16] = {"R/L:- OB:-" };

volatile bool lcd_update = 0;
int_fast32_t i32IPart[16], i32FPart[16];
 uint_fast32_t ui32Idx, ui32CompDCMStarted;
 float pfData[16];
 float *pfAccel, *pfGyro, *pfMag, *pfEulers, *pfQuaternion;

//*****************************************************************************
//
// The error routine that is called if the driver library encounters an error.
//
//*****************************************************************************
#ifdef DEBUG
void
__error__(char *pcFilename, uint32_t ui32Line)
{
}
#endif

//*****************************************************************************
//
// MPU9150 Sensor callback function.  Called at the end of MPU9150 sensor
// driver transactions. This is called from I2C interrupt context. Therefore,
// we just set a flag and let main do the bulk of the computations and display.
//
//*****************************************************************************
long map(long x, long in_min, long in_max, long out_min, long out_max) {
  return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}


void
MPU9150AppCallback(void *pvCallbackData, uint_fast8_t ui8Status)
{
    //
    // If the transaction succeeded set the data flag to indicate to
    // application that this transaction is complete and data may be ready.
    //
    if(ui8Status == I2CM_STATUS_SUCCESS)
    {
        g_vui8I2CDoneFlag = 1;
    }

    //
    // Store the most recent status in case it was an error condition
    //
    g_vui8ErrorFlag = ui8Status;
}

void IntGPIOb(void)
{
    unsigned long ulStatus;

    ulStatus = GPIOIntStatus(GPIO_PORTA_BASE, true);

    //
    // Clear all the pin interrupts that are set
    //
    GPIOIntClear(GPIO_PORTA_BASE, ulStatus);

    if(ulStatus & GPIO_PIN_2)
    {
        //
        // MPU9150 Data is ready for retrieval and processing.
        //
        MPU9150DataRead(&g_sMPU9150Inst, MPU9150AppCallback, &g_sMPU9150Inst);
    }
}

void MPU9150I2CIntHandler(void)
{
    //
    // Pass through to the I2CM interrupt handler provided by sensor library.
    // This is required to be at application level so that I2CMIntHandler can
    // receive the instance structure pointer as an argument.
    //
    I2CMIntHandler(&g_sI2CInst);
}

//*****************************************************************************
//
// MPU9150 Application error handler. Show the user if we have encountered an
// I2C error.
//
//*****************************************************************************

void MPU9150AppErrorHandler(char *pcFilename, uint_fast32_t ui32Line)
{
    //
    // Set terminal color to red and print error status and locations
    //
    UARTprintf("\033[31;1m");
    UARTprintf("Error: %d, File: %s, Line: %d\n"
               "See I2C status definitions in sensorlib\\i2cm_drv.h\n",
               g_vui8ErrorFlag, pcFilename, ui32Line);

    UARTprintf("\033[0m");

    while(1)
    {
        //
        // Do Nothing
        //
    }
}

//*****************************************************************************
//
// Function to wait for the MPU9150 transactions to complete. Use this to spin
// wait on the I2C bus.
//
//*****************************************************************************
void
MPU9150AppI2CWait(char *pcFilename, uint_fast32_t ui32Line)
{
    //
    // Put the processor to sleep while we wait for the I2C driver to
    // indicate that the transaction is complete.
    //
    while((g_vui8I2CDoneFlag == 0) && (g_vui8ErrorFlag == 0))
    {
        //
        // Do Nothing
        //
    }

    //
    // If an error occurred call the error handler immediately.
    //
    if(g_vui8ErrorFlag)
    {
        MPU9150AppErrorHandler(pcFilename, ui32Line);
    }

    //
    // clear the data flag for next use.
    //
    g_vui8I2CDoneFlag = 0;
}

void ConfigureUART(void)
{
    //
    // Enable the GPIO Peripheral used by the UART.
    //
//    ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);

    //
    // Enable UART0
    //
    ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_UART0);

    //
    // Configure GPIO Pins for UART mode.
    //
    ROM_GPIOPinConfigure(GPIO_PA0_U0RX);
    ROM_GPIOPinConfigure(GPIO_PA1_U0TX);
    ROM_GPIOPinTypeUART(GPIO_PORTA_BASE, GPIO_PIN_0 | GPIO_PIN_1);

    //
    // Use the internal 16MHz oscillator as the UART clock source.
    //
    UARTClockSourceSet(UART0_BASE, UART_CLOCK_PIOSC);

    //
    // Initialize the UART for console I/O.
    //
    UARTStdioConfig(0, 115200, 16000000);
}

void HC_SR04_setup(void)
{
    SYSCTL_RCGCGPIO_R |= 0x08;      // Enable clock to GPIO PORTD
    GPIO_PORTD_DIR_R |= 0x04;       // Set PD2 as output (trigger) and PD3 as input (echo)
    GPIO_PORTD_DEN_R |= 0x0C;       // Enable bit 2 and 3 of PORTD
    GPIO_PORTD_AFSEL_R |= 0x08;      // Set alternate function WTIMER3CCP1
    GPIO_PORTD_PCTL_R &= ~0x0000F000;
    GPIO_PORTD_PCTL_R |= 0x00007000;// PORTD bit 3 selected for alternate function

    // Set up timer WT3CCP1
    SYSCTL_RCGCWTIMER_R |= 8;       // Enable clock to to timer 3
    WTIMER3_CTL_R &= ~0x0100;       // Disable timer during setup
    WTIMER3_CFG_R = 0x00000004;     // 32 bit mode
    WTIMER3_TBILR_R = (657894);     // Timer LOAD REG value = 38 ms 657894
    // Configure TIMER_B
    // bits 1:0 = [11] Capture Mode
    // bit 2    = 1    Capture Mode - Edge Time
    // bit 3    = 0    Capture Mode enabled
    // bit 4    = 0    Count down
    WTIMER3_TBMR_R = 0x07;          // Configure TIMER_B
    WTIMER3_CTL_R |= 0x0C00;        // Detect both edges
    WTIMER3_CTL_R |= 0x0100;        // Enable Timer
    WTIMER3_ICR_R = 0x0400;         // Clear event interrupt flags
    WTIMER3_IMR_R |= 0x0400;        // Unmask interrupt for capture event mode

    NVIC_EN3_R |= 0x00000020;       // NVIC enabled (IRQ number = 102)
    NVIC_PRI25_R |= 0x00600000;     // Set priority = 3
}

void WTIMER3B_Handler(void)
{
    if((WTIMER3_MIS_R & 0x0400) && (GPIO_PORTD_DATA_R & 0x08))
    {
        time_value1 = WTIMER3_TBR_R;
    }
    if((WTIMER3_MIS_R & 0x0400) && !(GPIO_PORTD_DATA_R & 0x08))
    {
        time_value2 = (WTIMER3_TBR_R);
        update = 1;
    }
    WTIMER3_ICR_R = 0x0400 ;
}

void SYSTICK_HANDLER(void)
{
    trigger_delay++;
    log_msg++;
    GPIO_PORTA_DATA_R &= (~0X10);
    GPIO_PORTA_DATA_R &= (~0X08);
    GPIO_PORTA_DATA_R &= (~0X20);
    timer0_a_off;
    TIMER0_TAILR_R = timer0_a_load_value;  //1560-386; //1560 -386 ->+90 degrees   1453 TO 1200
    timer0_a_on;
    timer1_a_off;
    TIMER1_TAILR_R = timer1_a_load_value;   // 1560-386;  //196  1453 -> -90 degrees
    timer1_a_on;
    timer2_a_off;
    TIMER2_TAILR_R = timer2_a_load_value;  //1560-386; //1560 -386 ->+90 degrees   1453 TO 1200
    timer2_a_on;


    ROM_SysTickValueGet();
}

void Timer0_Handler(void)
{
    GPIO_PORTA_DATA_R |= 0X10;
    TIMER0_ICR_R  |= 1<<0;
    timer0_a_off;
}

void Timer1_Handler(void)
{
    GPIO_PORTA_DATA_R |= 0X08;
    TIMER1_ICR_R  |= 1<<0;
    timer1_a_off;

}
void Timer2_Handler(void)
{
    GPIO_PORTA_DATA_R |= 0X20;
    TIMER2_ICR_R  |= 1<<0;
       timer2_a_off;
}

void IntGPIOf(void)
{
    unsigned long ulStatus;

        ulStatus = GPIOIntStatus(GPIO_PORTF_BASE, true);
        GPIOIntClear(GPIO_PORTF_BASE, ulStatus);
//        set_base_speed = 1;
}

unsigned int calculate_distance(void)
{
    unsigned int distance;
    int time;
    if(time_value1 < time_value2)
    {
        time = time_value1 + (657894) - time_value2;
    }
    else
    {
        time = time_value1 - time_value2;
    }
    time = time/(16*2);
    distance = 34000*time/1000000;
    return distance;
}

void delay_us(unsigned int n)
{
    volatile unsigned int i,j;
    for(i=0;i<n;i++)
    {
        for(j=0;j<1;j++)
        {
        }
    }
}

void delay_ms(unsigned int n)
{
    volatile unsigned int i,j;
    for(i=0;i<n;i++)
    {
        for(j=0;j<3180;j++)
        {
        }
    }
}


void send_trigger_pulse(void)
{
    if(trigger_delay >15)
    {
    GPIO_PORTD_DATA_R &= ~0x04;
    delay_us(20);
    GPIO_PORTD_DATA_R |= 0x04;
    delay_us(10);
    GPIO_PORTD_DATA_R &= ~0x04;
    trigger_delay = 0;
    }
}

void gpio_init(void)
{
       SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);
       SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOF);
       SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOB);
       GPIOPinTypeGPIOOutput(GPIO_PORTA_BASE, 0XF8);   //PA3, PA4,PA5, PA6, PA7
       GPIOPinTypeGPIOOutput(GPIO_PORTB_BASE, 0XFF);
       GPIOPinWrite(GPIO_PORTA_BASE, 0XF8, 0);
       GPIOPinTypeGPIOOutput(GPIO_PORTF_BASE, 0X0E);
       GPIOPinTypeGPIOInput(GPIO_PORTF_BASE, 0X01);
       GPIO_PORTF_DATA_R = 0x00;

}


void i2c_init(void)
{
    SysCtlPeripheralEnable(SYSCTL_PERIPH_I2C2);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOE);
    GPIOPinConfigure(GPIO_PE4_I2C2SCL);
    GPIOPinConfigure(GPIO_PE5_I2C2SDA);
    GPIOPinTypeI2CSCL(GPIO_PORTE_BASE, GPIO_PIN_4);
    GPIOPinTypeI2C(GPIO_PORTE_BASE, GPIO_PIN_5);
}

void mpu_init(void)
{

     GPIOPinTypeGPIOInput(GPIO_PORTA_BASE, GPIO_PIN_2);
     GPIOIntEnable(GPIO_PORTA_BASE, GPIO_PIN_2);
     GPIOIntTypeSet(GPIO_PORTA_BASE, GPIO_PIN_2, GPIO_FALLING_EDGE);
     IntEnable(INT_GPIOA);
     ROM_IntMasterEnable();

     I2CMInit(&g_sI2CInst, I2C2_BASE, INT_I2C2, 0xff, 0xff,ROM_SysCtlClockGet());
     MPU9150Init(&g_sMPU9150Inst, &g_sI2CInst, MPU9150_I2C_ADDRESS, MPU9150AppCallback, &g_sMPU9150Inst);

     MPU9150AppI2CWait(__FILE__, __LINE__);

     // Filter settings
     g_sMPU9150Inst.pui8Data[0] = MPU9150_CONFIG_DLPF_CFG_94_98;
     g_sMPU9150Inst.pui8Data[1] = (MPU9150_ACCEL_CONFIG_ACCEL_HPF_5HZ | MPU9150_ACCEL_CONFIG_AFS_SEL_2G);
     MPU9150Write(&g_sMPU9150Inst, MPU9150_O_CONFIG, g_sMPU9150Inst.pui8Data, 2,MPU9150AppCallback, &g_sMPU9150Inst);

     MPU9150AppI2CWait(__FILE__, __LINE__);

     // Configure the data ready interrupt pin output of the MPU9150.
     g_sMPU9150Inst.pui8Data[0] = MPU9150_INT_PIN_CFG_INT_LEVEL |MPU9150_INT_PIN_CFG_INT_RD_CLEAR | MPU9150_INT_PIN_CFG_LATCH_INT_EN;
     g_sMPU9150Inst.pui8Data[1] = MPU9150_INT_ENABLE_DATA_RDY_EN;
     MPU9150Write(&g_sMPU9150Inst, MPU9150_O_INT_PIN_CFG,g_sMPU9150Inst.pui8Data, 2, MPU9150AppCallback,&g_sMPU9150Inst);

     MPU9150AppI2CWait(__FILE__, __LINE__);

}




void systick_setup(void)
{

          ROM_SysTickPeriodSet(400000-1);
          ROM_SysTickIntEnable();
          ROM_SysTickEnable();
}

void timer0_a_setup(void)   // for main motor
{
            SYSCTL_RCGCTIMER_R |= 1<<0;
            TIMER0_CTL_R &= (~(1<<0));
            TIMER0_CFG_R = 0X4;
            TIMER0_TAMR_R = 0X2;
            TIMER0_TAPR_R |= 0XFF;
            TIMER0_TAILR_R = 1570/2;
            TIMER0_ICR_R |= 1<<0;
            TIMER0_CTL_R |= 1<<0;
            TIMER0_IMR_R |= 1<<0;
            NVIC_EN0_R |= 0X80000; // INTERRUPT 19
}



void timer1_a_setup(void)    // for tail motor
{
        SYSCTL_RCGCTIMER_R |= 1<<1;
        TIMER1_CTL_R &= (~(1<<0));
        TIMER1_CFG_R = 0X4;
        TIMER1_TAMR_R = 0X2;
        TIMER1_TAPR_R |= 0XFF;
        TIMER1_TAILR_R = 1570/2;
        TIMER1_ICR_R |= 1<<0;
        TIMER1_CTL_R |= 1<<0;
        TIMER1_IMR_R |= 1<<0;
        NVIC_EN0_R |= 0X200000; // INTERRUPT 21

}

void timer2_a_setup(void)   // for servo motor
{
            SYSCTL_RCGCTIMER_R |= 1<<2;
            TIMER2_CTL_R &= (~(1<<0));
            TIMER2_CFG_R = 0X4;
            TIMER2_TAMR_R = 0X2;
            TIMER2_TAPR_R |= 0XFF;
            TIMER2_TAILR_R = 1570/2;
            TIMER2_ICR_R |= 1<<0;
            TIMER2_CTL_R |= 1<<0;
            TIMER2_IMR_R |= 1<<0;
            NVIC_EN0_R |= 0X800000; // INTERRUPT 23
}

void main_motor_check(void)
{
    ClearLCD();
    writeStringLCD("MAIN MOTOR CHECK", 1);
    int i = 0;
    for(i = 0; i<51 ; i++)
    {
        timer0_a_load_value = i*30;
        delay_ms(200);
    }
}

void tail_motor_check(void)
{
    int i = 0;
    ClearLCD();
    writeStringLCD("TAIL MOTOR CHECK", 1);
    for(i = 0; i<51 ; i++)
    {
        timer1_a_load_value = i*30;
        delay_ms(200);
    }

}

void servo_motor_check(void)
{
    int i = 0;
       ClearLCD();
       writeStringLCD("SERVO MOTOR CHECK", 1);  // 1200 TO 1450
       for(i = 0; i<45 ; i++)
       {
           timer2_a_load_value = 1000 + i*10;
           delay_ms(100);
       }
       delay_ms(2000);

       for(i = 0; i<45 ; i++)
       {
           timer2_a_load_value = 1450 - i*10;
           delay_ms(100);
       }
       timer2_a_load_value = 1450;

}

void lcd_show(void)
{
                   writeStringLCD(lcd_msg_1, 1);
                   writeStringLCD(lcd_msg_2, 2);
}

void get_mpu_data(void)
{
    if(g_vui8I2CDoneFlag == 1)
    {
        g_vui8I2CDoneFlag = 0;
                    MPU9150DataAccelGetFloat(&g_sMPU9150Inst, pfAccel, pfAccel + 1,
                                             pfAccel + 2);

                    //
                    // Get floating point version of angular velocities in rad/sec
                    //
                    MPU9150DataGyroGetFloat(&g_sMPU9150Inst, pfGyro, pfGyro + 1,
                                            pfGyro + 2);

                    //
                    // Get floating point version of magnetic fields strength in tesla
                    //
                    MPU9150DataMagnetoGetFloat(&g_sMPU9150Inst, pfMag, pfMag + 1,
                                               pfMag + 2);

                    //
                    // Check if this is our first data ever.
                    //
                    if(ui32CompDCMStarted == 0)
                    {
                        //
                        // Set flag indicating that DCM is started.
                        // Perform the seeding of the DCM with the first data set.
                        //
                        ui32CompDCMStarted = 1;
                        CompDCMMagnetoUpdate(&g_sCompDCMInst, pfMag[0], pfMag[1],
                                             pfMag[2]);
                        CompDCMAccelUpdate(&g_sCompDCMInst, pfAccel[0], pfAccel[1],
                                           pfAccel[2]);
                        CompDCMGyroUpdate(&g_sCompDCMInst, pfGyro[0], pfGyro[1],
                                          pfGyro[2]);
                        CompDCMStart(&g_sCompDCMInst);
                    }
                    else
                    {
                        //
                        // DCM Is already started.  Perform the incremental update.
                        //
                        CompDCMMagnetoUpdate(&g_sCompDCMInst, pfMag[0], pfMag[1],
                                             pfMag[2]);
                        CompDCMAccelUpdate(&g_sCompDCMInst, pfAccel[0], pfAccel[1],
                                           pfAccel[2]);
                        CompDCMGyroUpdate(&g_sCompDCMInst, -pfGyro[0], -pfGyro[1],
                                          -pfGyro[2]);
                        CompDCMUpdate(&g_sCompDCMInst);
                    }

                    g_ui32PrintSkipCounter++;

    }

    if(g_ui32PrintSkipCounter >= PRINT_SKIP_COUNT)
             {

                 g_ui32PrintSkipCounter = 0;

                 CompDCMComputeEulers(&g_sCompDCMInst, pfEulers, pfEulers + 1,
                                      pfEulers + 2);


                 CompDCMComputeQuaternion(&g_sCompDCMInst, pfQuaternion);

                 //
                 // convert mag data to micro-tesla for better human interpretation.
                 //
                 pfMag[0] *= 1e6;
                 pfMag[1] *= 1e6;
                 pfMag[2] *= 1e6;

                 //
                 // Convert Eulers to degrees. 180/PI = 57.29...
                 // Convert Yaw to 0 to 360 to approximate compass headings.
                 //
                 pfEulers[0] *= 57.295779513082320876798154814105f;
                 pfEulers[1] *= 57.295779513082320876798154814105f;
                 pfEulers[2] *= 57.295779513082320876798154814105f;
                 if(pfEulers[2] < 0)
                 {
                     pfEulers[2] += 360.0f;
                 }

                 //
                 // Now drop back to using the data as a single array for the
                 // purpose of decomposing the float into a integer part and a
                 // fraction (decimal) part.
                 //

                 for(ui32Idx = 0; ui32Idx < 16; ui32Idx++)
                 {
                     //
                     // Conver float value to a integer truncating the decimal part.
                     //
                     i32IPart[ui32Idx] = (int32_t) pfData[ui32Idx];

                     //
                     // Multiply by 1000 to preserve first three decimal values.
                     // Truncates at the 3rd decimal place.
                     //
                     i32FPart[ui32Idx] = (int32_t) (pfData[ui32Idx] * 1000.0f);

                     //
                     // Subtract off the integer part from this newly formed decimal
                     // part.
                     //
                     i32FPart[ui32Idx] = i32FPart[ui32Idx] -
                                         (i32IPart[ui32Idx] * 1000);

                     //
                     // make the decimal part a positive number for display.
                     //
                     if(i32FPart[ui32Idx] < 0)
                     {
                         i32FPart[ui32Idx] *= -1;
                     }
                 }


                 present_x_val = pfAccel[0];
                 present_y_val = pfAccel[1];
                 present_z_val = pfAccel[2];
                 present_pitch = pfEulers[0];
                 present_yaw = pfEulers[2];

                 int pitch_var = 0;
                 int z_var = 0;
                 if(present_x_val < -2.0 || present_x_val > 2.0 || present_y_val <-2.0 || present_y_val>2.0)
                     z_var = 1;

                 lcd_msg_1[4] = '-';
                 lcd_msg_1[10] = '-';
                 lcd_msg_2[4] = '-';

                 if((present_z_val - last_z_val > 0.8 || last_z_val - present_z_val > 0.8) && (z_var == 0))
                 {
                     if(present_z_val - last_z_val > 0.8)
                     lcd_msg_1[4] = 'D';
                     else if(last_z_val - present_z_val > 0.8)
                     lcd_msg_1[4] = 'A';
//                     timer0_a_load_value = map(((present_z_val - last_z_val)*10), -30, 30, 10, 1560);
//                     lcd_show();
                     asc_des = 1;
                 }

                 if((present_yaw - last_yaw > 5 || last_yaw - present_yaw > 5)&&(pitch_var == 0))
                 {
                     if(present_yaw - last_yaw > 5)
                         lcd_msg_2[4] = 'R';
                     else if(last_yaw - present_yaw > 5)
                     lcd_msg_2[4] = 'L';
//                     lcd_show();

                     timer1_a_load_value = map((present_yaw), 0 , 360 , 10, 1560);
                 }

                 if((present_pitch - last_pitch > 10 || last_pitch - present_pitch > 10))
                     {
                           if(present_pitch - last_pitch>10)
                               lcd_msg_1[10] = 'F';
                           else if(last_pitch - present_pitch > 10)
                           lcd_msg_1[10] = 'B';
//                           lcd_show();

                         timer2_a_load_value = map((present_pitch), -90, 90, 1200, 1450);
                         timer1_a_load_value = 1450;
//                         timer0_a_load_value = 1450;
                     }
                 last_pitch = present_pitch;
                 last_yaw = present_yaw;
                 last_z_val = present_z_val;
             }

}

void adc_setup(void)
{

    SYSCTL_RCGCGPIO_R |= 0x00000010;        // Enable clock at GPIOE (for ADC0)
    SYSCTL_RCGCADC_R |= 0x00000001;         // Enable clock at ADC0 module - bit 0
    GPIO_PORTE_AFSEL_R |= 8;                // Enable alternate function for PORTE bit 3
    GPIO_PORTE_DEN_R &= ~8;                 // Disable digital function for PORTE bit 3
    GPIO_PORTE_AMSEL_R |= 8;                // Enable analog function for PORTE bit 3

    // ADC0 configurations
    // safe practice to disable ADC Sample Sequencer before initializing other registers and then enable again
    // Using Sample Sequencer 3 (One 12-bit Sample FIFO)

    ADC0_ACTSS_R &= ~8;                     // Disable SS3 during configuration
    ADC0_EMUX_R &= ~0x0000F000;             // Software trigger conversion
    ADC0_SSMUX3_R = 0;                      // Enable input from channel 0 (PORTE bit 3)
    ADC0_SSCTL3_R |= 6;                     // Take one sample at a time, set flag at 1st sample
    ADC0_ACTSS_R |= 8;                      // enable ADC0 sequencer 3

}


void get_adc_data(void)
{
    ADC0_PSSI_R |= 8; /* start a conversion sequence 3 */
                    while((ADC0_RIS_R & 8) == 0)
                    {
                    }
                     /* wait for conversion complete */
                    result = ADC0_SSFIFO3_R; /* read conversion result */
                    ADC0_ISC_R = 8; /* clear completion flag */
}

void print_uart_msg(void)
{
    log_msg = 0;
UARTprintf("***********Sensor values***********\n\r");
UARTprintf("Accel x value -> %d.%03d\n\r",i32IPart[0],i32FPart[0]);
UARTprintf("Accel y value -> %d.%03d\n\r",i32IPart[1],i32FPart[1]);
UARTprintf("Accel z value -> %d.%03d\n\r",i32IPart[2],i32FPart[2]);

UARTprintf("EULER'S PITCH -> %d.%03d\n\r",i32IPart[9],i32FPart[9]);
UARTprintf("EULER'S ROLL  -> %d.%03d\n\r",i32IPart[10],i32FPart[10]);
UARTprintf("EULER'S   YAW -> %d.%03d\n\r",i32IPart[11],i32FPart[11]);

UARTprintf("DISTANCE      -> %d\n\r",distance);

UARTprintf("\n\r");
UARTprintf("\n\r");

}


int main(void)
{
    int last_result = 0;
     pfAccel = pfData;
     pfGyro = pfData + 3;
     pfMag = pfData + 6;
     pfEulers = pfData + 9;
     pfQuaternion = pfData + 12;

    // Setup the system clock to run at 40 Mhz from PLL with crystal reference
    ROM_SysCtlClockSet(SYSCTL_SYSDIV_5 | SYSCTL_USE_PLL | SYSCTL_XTAL_16MHZ | SYSCTL_OSC_MAIN);

      gpio_init();
      ConfigureUART();
      i2c_init();
      mpu_init();
      LCD_Initialization();
      ClearLCD();
      HC_SR04_setup();
      systick_setup();
      timer0_a_setup();
      timer1_a_setup();
      timer2_a_setup();
      adc_setup();
      main_motor_check();
      tail_motor_check();
      servo_motor_check();
      ClearLCD();
      writeStringLCD("INIT DONE", 1);

      delay_us(10000);
      CompDCMInit(&g_sCompDCMInst, 1.0f / 50.0f, 0.2f, 0.6f, 0.2f);

      g_vui8I2CDoneFlag = 0;

    while(1)
    {
        send_trigger_pulse();
        get_mpu_data();
        get_adc_data();
        if(result-last_result > 50 || last_result-result > 50)
        {
            timer1_a_load_value = map(result, 0, 4095, 1560, 10);
            timer0_a_load_value = map(result, 0, 4095, 1560, 10);

            last_result = result;
        }

        if(update)  //ultra sonic data
        {
            distance = calculate_distance();
            update = 0;
            lcd_msg_2[9] = 'N';
            lcd_update = 1;
            if(distance < 30 || asc_des)
            {
               if(asc_des)
               {
                   GPIO_PORTF_DATA_R ^= 0X08;
                   asc_des = 0;
               }
               else
               {
                   GPIO_PORTF_DATA_R ^= 0X0A;
                   lcd_msg_2[9] = 'Y';
//                   lcd_show();
               }
               }
            else
            {
                GPIO_PORTF_DATA_R = 0x00;
            }

            if(log_msg>200)
            {
            print_uart_msg();
            lcd_show();
            }

        }

    }
}
