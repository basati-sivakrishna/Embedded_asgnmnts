/*
 * ultra_sonic.h
 *
 *  Created on: 02-Apr-2024
 *      Author: basat
 */

#ifndef ULTRA_SONIC_H_
#define ULTRA_SONIC_H_

void init_ultra_sonic(void);
void send_pulse(void);
int measure_distance(int ticks);


#endif /* ULTRA_SONIC_H_ */
